var ganttData = [
	{
		id: 1, name: "Feature 1", series: [
			{ title: "Planned", start: new Date(2010,00,01), end: new Date(2010,00,03) },
			{ title: "Actual", start: new Date(2010,00,02), end: new Date(2010,00,05), color: "#f0f0f0" }
		]
	}
];
