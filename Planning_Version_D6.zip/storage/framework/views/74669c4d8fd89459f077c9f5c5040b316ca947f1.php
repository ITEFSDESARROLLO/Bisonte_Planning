<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">Nuevo > Ordenes de Producción</div>
                    <!--<script>window.alert("Algunas Funciones se estan Actualizando")</script>-->

                    <div class="card-body">
                        <form class="" method="POST" action="<?php echo e(url('ProcesosProduccion/'.$data->id)); ?>">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('PUT')); ?>

                            <div class="position-relative form-group">
                                <label for="nameTags" class="">Nombre</label>
                                <input name="name" id="nameTags"
                                       placeholder=""
                                       value="<?php echo e($data->name ?: ''); ?>"
                                       type="text"
                                       class="form-control">
                            </div>
                            <div class="position-relative form-group">
                                <label for="cantidadTags" class="">Cantidad</label>
                                <input name="cantidad" id="cantidadTags"
                                       placeholder=""
                                       value="<?php echo e($data->cantidad ?: ''); ?>"
                                       type="integer"
                                       class="form-control">
                            </div>
                            <div class="position-relative form-group">
                                <label for="startAtTags" class="">Inicio</label>
                                <input name="start_at" id="startAtTags"
                                       placeholder=""
                                       type="time"
                                       value="<?php echo e($data->start_at ? Carbon\Carbon::parse($data->start_at)->format('H:i:s'): ''); ?>"
                                       class="form-control">
                            </div>
                            <div class="position-relative form-group">
                                <label for="deadLineAtTags" class="">Final</label>
                                <input name="deadline_at" id="deadLineAtTags"
                                       placeholder=""
                                       type="time"
                                       value="<?php echo e($data->deadline_at ? Carbon\Carbon::parse($data->deadline_at)->format('H:i:s'): ''); ?>"
                                       class="form-control">
                            </div>
                            <div class="position-relative form-group">
                                <label for="colorTags" class="">Color</label>
                                <input name="color" id="colorTags"
                                       placeholder=""
                                       type="color"
                                       value="<?php echo e($data->color ?: ''); ?>"
                                       class="form-control">
                            </div>
                            <div class="position-relative form-group">
                                <label for="projectTags" class="">Proyectos</label>
                                <select name="projects_id" id="projectTags" class="form-control">
                                    <?php $__currentLoopData = $LineasProduccion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option
                                            <?php echo e((($data->LineasProduccion) && ($data->LineasProduccion->id === $project->id)) ? 'selected' : ''); ?>

                                            value="<?php echo e($project->id); ?>"><?php echo e($project->title); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>


                            <!--<?php echo $data->trix('content'); ?>-->

                            <button class="mt-1 btn btn-primary">Enviar</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript">

        function setValue(text = '') {
            const trixEditor = document.querySelector("trix-editor")
            trixEditor.editor.insertHTML(text);
        }

        document.addEventListener("DOMContentLoaded", function (event) {
            setValue(`<?php echo $data->content; ?>`)
        });

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ITEFS-BACKEND\Documents\Desarrrollo Bisonte Pruebas\Report_OriginalHoras\Report_Original16\resources\views/ProcesosProduccion/edit.blade.php ENDPATH**/ ?>