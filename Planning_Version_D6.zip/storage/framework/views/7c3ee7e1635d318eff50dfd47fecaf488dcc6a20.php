<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">Dashboard</div>

                    <div class="card-body">
                        <div class="col-md-12 row m-0">
                            <div class="col-2 mb-2 over-block-card card p-3 text-center">
                                <a class="btn btn-default text-center" href="reports">
                                    <i class="fas fa-share-square fa-3x"></i>
                                    <div class="mt-2">Asignaciones</div>
                                </a>
                            </div>
                            <div class="col-2 mb-2 over-block-card card p-3 text-center">
                                <a class="btn btn-default" href="organizations">
                                    <i class="fas fa-users-cog fa-3x"></i>
                                    <div class="mt-2">Encargado</div>
                                </a>
                            </div>
                            <div class="col-2 mb-2 over-block-card card p-3 text-center">
                                <a class="btn btn-default" href="projects">
                                    <i class="fas fa-folder-open fa-3x"></i>
                                    <div class="mt-2">Proyecto</div>
                                </a>
                            </div>
                            <div class="col-2 mb-2 over-block-card card p-3 text-center">
                                <a class="btn btn-default" href="features">
                                    <i class="fas fa-ellipsis-v fa-3x"></i>
                                    <div class="mt-2">Caracteristicas</div>
                                </a>
                            </div>
                            <div class="col-2 mb-2 over-block-card card p-3 text-center">
                                <a class="btn btn-default" href="tags">
                                    <i class="fas fa-tasks fa-3x"></i>
                                    <div class="mt-2">Actividades</div>
                                </a>
                            </div>
                            <div class="col-2 mb-2 over-block-card card p-3 text-center">
                                <a class="btn btn-default" href="chart">
                                    <i class="fas fa-project-diagram fa-3x"></i>
                                    <div class="mt-2">Planning</div>
                                </a>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\n.moreno.GLSLOG\Documents\APP\Report_Original\resources\views/home.blade.php ENDPATH**/ ?>