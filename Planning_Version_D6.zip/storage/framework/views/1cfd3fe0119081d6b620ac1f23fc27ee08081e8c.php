<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">Editar > Usuario</div>

                    <div class="card-body">
                        <form class="" method="POST" action="<?php echo e(url('usuarios/'.$data->id)); ?>">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('PUT')); ?>

                            <div class="position-relative form-group">
                                <label for="identificacionOrganizations" class="">Numero de Identificación</label>
                                <input name="name" id="nameOrganizations"
                                       value="<?php echo e($data->name ?: ''); ?>"
                                       placeholder=""
                                       type="number"
                                       class="form-control">
                            </div>
                            <div class="position-relative form-group">
                                <label for="nameOrganizations" class="">Nombre</label>
                                <input name="contact" id="contactOrganizations"
                                       value="<?php echo e($data->contact ?: ''); ?>"
                                       placeholder=""
                                       type="text"
                                       class="form-control">
                            </div>
                            <div class="position-relative form-group">
                                <label for="urlOrganizations" class="">Rol</label>
                                <input name="url" id="urlOrganizations"
                                       placeholder=""
                                       value="<?php echo e($data->url ?: ''); ?>"
                                       type="text"
                                       class="form-control">
                            </div>
                            <div class="position-relative form-group">
                                <label for="emailOrganizations" class="">Email</label>
                                <input name="email" id="emailOrganizations"
                                       placeholder=""
                                       type="email"
                                       value="<?php echo e($data->email ?: ''); ?>"
                                       class="form-control">
                            </div>
                            <button class="mt-1 btn btn-primary">Enviar</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ITEFS-BACKEND\Documents\Desarrrollo Bisonte Pruebas\Report_Original\resources\views/usuarios/edit.blade.php ENDPATH**/ ?>