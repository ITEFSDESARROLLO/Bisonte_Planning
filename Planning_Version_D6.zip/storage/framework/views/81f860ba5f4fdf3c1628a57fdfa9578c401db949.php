<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">Edit > Project</div>

                    <div class="card-body">
                        <form class="" method="POST" action="<?php echo e(url('projects/'.$data->id)); ?>">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('PUT')); ?>

                            <div class="position-relative form-group">
                                <label for="titleProjects" class="">Titulo</label>
                                <input name="title" id="titleProjects"
                                       placeholder=""
                                       value="<?php echo e($data->title ?: ''); ?>"
                                       type="text"
                                       class="form-control">
                            </div>
                            <div class="position-relative form-group">
                                <label for="organizationsProjects" class="">Organizacion</label>
                                <select name="organizations_id" id="organizationsProjects" class="form-control">
                                    <?php $__currentLoopData = $organizations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $organization): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option
                                            <?php echo e(($data->organizations_id === $organization->id) ? 'selected': ''); ?>

                                            value="<?php echo e($organization->id); ?>"><?php echo e($organization->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="position-relative form-group">
                                <label for="urlProjects" class="">Url</label>
                                <input name="url" id="urlProjects"
                                       placeholder=""
                                       value="<?php echo e($data->url ?: ''); ?>"
                                       type="url"
                                       class="form-control">
                            </div>
                            <div class="position-relative form-group">
                                <label for="descriptionProjects" class="">Descripcion</label>
                                <textarea name="description" id="descriptionProjects"
                                          placeholder=""
                                          class="form-control">
                                       <?php echo e($data->description ?: ''); ?>

                                </textarea>
                            </div>
                            <button class="mt-1 btn btn-primary">Enviar</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ITEFS-BACKEND\Documents\Desarrrollo Bisonte Pruebas\Report_Original\resources\views/projects/edit.blade.php ENDPATH**/ ?>