<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">Edit > Project</div>

                    <div class="card-body">
                        <form class="" method="POST" action="<?php echo e(url('producto/'.$data->id)); ?>">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('PUT')); ?>


                            <div class="position-relative form-group">
                                <label for="codigoProducto" class="">Codigo</label>
                                <input name="codigo" id="codigoProducto"
                                       placeholder=""
                                       value="<?php echo e($data->codigo ?: ''); ?>"
                                       type="integer"
                                       class="form-control">
                            </div>
                            <div class="position-relative form-group">
                                <label for="nameFeatures" class="">Nombre</label>
                                <input name="name" id="nameFeatures"
                                       placeholder=""
                                       value="<?php echo e($data->name ?: ''); ?>"
                                       type="text"
                                       class="form-control">
                            </div>
                            <div class="position-relative form-group">
                                <label for="descriptionFeatures" class="">Unid x Hora</label>
                                <textarea name="description" id="descriptionFeatures"
                                          placeholder=""
                                          class="form-control">
                                    <?php echo e($data->description ?: ''); ?>

                                </textarea>
                            </div>
                            <div class="position-relative form-group">
                                <label for="default_valueFeatures" class="">Pre seleccionado</label>
                                <select name="default_value" id="default_valueFeatures" class="form-control">
                                    <option
                                        <?php echo e(($data->default_value == 1) ? 'selected': ''); ?> value="1">
                                        Si
                                    </option>
                                    <option
                                        <?php echo e(($data->default_value == 0) ? 'selected': ''); ?>  value="0">
                                        No
                                    </option>
                                </select>
                            </div>
                            <button class="mt-1 btn btn-primary">Enviar</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ITEFS-BACKEND\Documents\Desarrrollo Bisonte Pruebas\Report_Original\resources\views/Producto/edit.blade.php ENDPATH**/ ?>