<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="app-page-title m-0">
                        <div class="page-title-wrapper">
                            <div class="page-title-heading">
                                <div class="page-title-icon">
                                    <i class="fas fa-file-word "></i>
                                </div>
                                <div>Asignaciones
                                </div>
                            </div>
                            <div class="page-title-actions">
                                <a href="/reports/create" type="button" data-toggle="tooltip" title=""
                                   data-placement="bottom"
                                   class="btn-primary mr-3 btn over-block-card" data-original-title="Example Tooltip">
                                    Nuevo
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="pl-4 pr-4 pb-2 pt-2">
                        <input id="date-range0" value="" placeholder="Rango de fechas"
                               class="form-control form-date-input">
                    </div>
                    <div class="card-body">
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card mb-3 opacity-full"
                                 style="<?php echo e(!$d->is_range ? 'opacity:.3':'aa'); ?>">
                                <div class="card-header d-flex justify-content-between">
                                    <div data-toggle="tooltip"
                                         data-original-title="<?php echo e($d->project->organization->name); ?>">
                                        <?php echo e(Carbon\Carbon::parse($d->date_begin)->format('d M Y')); ?> /
                                        <?php echo e(Carbon\Carbon::parse($d->date_finish)->format('d M Y')); ?> <i
                                            class="fas fa-angle-right"></i>
                                        <?php echo e($d->project->title); ?>

                                        <span class="font-italic">(<?php echo e($d->hours_all); ?>)</span>
                                    </div>
                                    <div class="d-flex">
                                        <a href="/reports/<?php echo e($d->id); ?>" class="btn btn-sm"
                                           data-toggle="tooltip" title=""
                                           data-original-title="Issues">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="/reports/<?php echo e($d->id); ?>/edit" class="btn btn-sm"
                                           data-toggle="tooltip" title=""
                                           data-original-title="Editar">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <form method="POST" action="/reports/<?php echo e($d->id); ?>">
                                            <?php echo e(csrf_field()); ?>

                                            <?php echo e(method_field('DELETE')); ?>

                                            <button class="btn-sm btn">
                                                <i class="fas fa-trash-alt"></i>
                                            </button>
                                        </form>
                                        <a href="/issues/create?report=<?php echo e($d->id); ?>"
                                           class="btn btn-sm text-success"
                                           data-toggle="tooltip" title=""
                                           data-original-title="Issues">
                                            <i class="fas fa-plus-square"></i>
                                        </a>

                                    </div>
                                </div>
                                <div class="card-body">
                                    <?php if(count($d->issues)): ?>
                                        <blockquote class="blockquote mb-0 report-text-block">
                                            <ul class="m-0 p-0">
                                                <?php $__currentLoopData = $d->issues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li data-toggle="tooltip"
                                                        data-original-title="Tag: <?php echo e($i->get_tag->name); ?> - <?php echo e($i->hours); ?> horas"
                                                        class="badge badge-light-gray mb-1">
                                                        <canvas class="pointer-color"
                                                                style="background-color: <?php echo e($i->get_tag->color); ?>"></canvas>
                                                        <?php echo e($i->title); ?></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </ul>
                                        </blockquote>
                                    <?php else: ?>
                                        <div class="text-center p-3">
                                            <a href="/issues/create?report=<?php echo e($d->id); ?>"
                                               class="btn btn-sm"
                                               data-toggle="tooltip" title=""
                                               data-original-title="Issues">
                                                <div>
                                                    <i class="fas fa-folder-open fa-3x"></i>
                                                </div>
                                                <div class="p-1">

                                                    <i>Sin contenido</i>
                                                </div>
                                            </a>

                                        </div>

                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-12">


                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="card p-2 pl-3 pr-3">
                            <strong>Total: <?php echo e($general['hours']); ?> <span class="text-muted">(horas)</span></strong>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\n.moreno.GLSLOG\Documents\APP\Report_Original\resources\views/reports/view.blade.php ENDPATH**/ ?>