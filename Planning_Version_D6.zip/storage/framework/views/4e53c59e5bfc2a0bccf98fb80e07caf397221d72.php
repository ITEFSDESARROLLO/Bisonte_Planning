<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">Ver > Asignacion > <?php echo e($report->project->title); ?> >
                        <?php echo e(Carbon\Carbon::parse($report->date_begin)->format('d/M/Y')); ?>

                        <?php echo e(Carbon\Carbon::parse($report->date_finish)->format('d/M/Y')); ?>

                    </div>
                    <div class="card-body">
                        <form class="" method="POST" action="<?php echo e(url('Producto/'.$report->id)); ?>">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('PUT')); ?>

                            <div class="p-4 line-height-report">
                                <h6><strong><?php echo e($report->project->title); ?></strong></h6>
                                <?php $__currentLoopData = $report->ProdLineasAgregar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <ul>
                                      <!--  <li><strong>(<?php echo e($r->hours); ?> horas)</strong></li>-->
                                        <?php if($r->issue_features): ?>
                                            <ul>
                                                <?php $__currentLoopData = $r->issue_features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><?php echo e($f->detail->name); ?> <span class="font-italic text-muted">(<?php echo e($f->hours); ?> horas)</span></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        <?php endif; ?>
                                    </ul>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ITEFS-BACKEND\Documents\Desarrrollo Bisonte Pruebas\Bisonte_Planning_Version_D\resources\views/Asignaciones/show.blade.php ENDPATH**/ ?>