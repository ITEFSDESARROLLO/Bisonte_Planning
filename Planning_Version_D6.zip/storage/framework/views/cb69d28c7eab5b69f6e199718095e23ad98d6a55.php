<?php $__env->startSection('chart-canvas'); ?>
    <div class="p-1" id="viewport-chart">
        <div class="m-0" style="overflow-y: auto" id="ganttChart"></div>
        <br/><br/>
        <div id="eventMessage"></div>
        <div id="footer-section-chart" class="footer-section-chart" style="position: fixed; top: 0; width: 100%;">
       <!-- <script >window.alert('Algunas Funciones Estan en Construccion')</script>-->
            <div class="pull-right">
                <button class="btn btn-sm btn-default" id="close-btn" onclick="closeKeepNote()"><i
                        class="fas fa-times"></i></button>

            </div>
            <div class="inside-content">
                <div class="mb-1"><strong> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eveniet,
                        non?</strong>


                </div>
                <div>
                    <ul class="font-italic">
                        <li>Lorem ipsum dolor.</li>
                        <li>Lorem ipsum dolor.</li>
                        <li>Lorem ipsum dolor.</li>
                        <li>Lorem ipsum dolor.</li>
                        <li>Lorem ipsum dolor.</li>
                        <li>Lorem ipsum dolor.</li>
                        <li>Lorem ipsum dolor.</li>
                        <li>Lorem ipsum dolor.</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        const footerElement = document.querySelector('#footer-section-chart');

        function parseDate(data = {}) {
            data.forEach(a => {
                return a;
            })
            return data;
        }

        function closeKeepNote(event) {
            footerElement.style.display = 'none'
        }

        function addNewSection() {
            const divFooter = document.querySelector('#viewport-chart')
        }


        document.addEventListener("DOMContentLoaded", function (event) {


            jQuery("#ganttChart").ganttView({
                data: <?php echo json_encode($data, 15, 512) ?>,
                slideWidth: '100%',
                behavior: {
                    onClick: function (data) {
                        window.open(`/Asignaciones/${data.id}`)
                    },
                    draggable: false,
                    resizable: false
                },
                // Modificación: Configurar el formato de la hora en horas
                hoursFormat: 'HH:mm'
            }).then(r => {
                const parentDiv = document.querySelector('#viewport-chart .ganttview-slide-container');
                const pointer = document.querySelector('#viewport-chart .current_day').style;
                pointer.setProperty('--width_all', `${parseFloat(parentDiv.offsetHeight - 20)}px`);
            })

            const elementHover = document.querySelectorAll('.ganttview-vtheader-series-name');

            elementHover.forEach(function (elem) {

                elem.addEventListener("mouseover", function (event) {
                    // highlight the mouseover target
                    if (elem.dataset.content) {
                        footerElement.style.display = 'block';
                    }
                    footerElement.querySelector('.inside-content').innerHTML = `${(elem.dataset.content) ? elem.dataset.content : ''}`;
                    event.target.style.color = "orange";
                    // reset the color after a short delay
                    // setTimeout(function () {
                    event.target.style.color = "";
                    //     footerElement.style.display = 'none';
                    // }, 500);
                }, false);
            });

        });


    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ITEFS-BACKEND\Documents\Desarrrollo Bisonte Pruebas\Planning_Version_A2\Planning_Version_A\resources\views/chart/view.blade.php ENDPATH**/ ?>