<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">Nuevo > Asignacion de Producto > <?php echo e($report->project->title); ?></div>

                    <div class="card-body">
                        <form class="" method="POST" action="<?php echo e(url('ProdLineasAgregar')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="projects_id" value="<?php echo e($report->project->id); ?>">
                            <input type="hidden" name="report_id" value="<?php echo e($report->id); ?>">

                            <div class="position-relative form-group">
                                <label for="titleProjects" class="">Numero de Orden</label>
                                <select name="title" id="titleProjects" class="form-control">
                                <?php $__currentLoopData = $ProcesosProduccion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($tag->id); ?>"><?php echo e($tag->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>
                            </div>

                            <div class="position-relative form-group">
                                <label for="tagIssues" class="">Asignar Orden De Fabricacíon</label>
                                <select name="tag_id" id="tagIssues" class="form-control">
                                    <?php $__currentLoopData = $ProcesosProduccion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($tag->id); ?>"><?php echo e($tag->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="position-relative form-group">
                                    <?php $__currentLoopData = $Producto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="position-relative form-group">
                                <?php $__currentLoopData = $ProcesosProduccion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <input id="check_<?php echo e($feature->id); ?>" name="Producto[<?php echo e($feature->id); ?>]"
                                                 value="<?php echo e($feature->id); ?>" >
                                                <label for="check_<?php echo e($feature->id); ?>"><?php echo e($feature->featured_id); ?></label>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                                          <!--  <td>
                                                <input name="hours_list[<?php echo e($feature->id); ?>]" id="nameFeatures"
                                                       placeholder=""
                                                       type="number"
                                                       class="form-control">
                                            </td>-->
                            </div>
                            <div class="position-relative form-group">
                                <label for="developerIssues" class="">Developer</label>
                                <select name="users_id" id="developerIssues" class="form-control">
                                    <?php $__currentLoopData = $developers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $developer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($developer->id); ?>"><?php echo e($developer->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <button class="mt-1 btn btn-primary">Enviar</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ITEFS-BACKEND\Documents\Desarrrollo Bisonte Pruebas\Planning_Version_A2\Planning_Version_A\resources\views/ProdLineasAgregar/create.blade.php ENDPATH**/ ?>