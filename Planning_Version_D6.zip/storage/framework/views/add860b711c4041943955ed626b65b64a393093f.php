<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="description" content="Itefs">
    <meta name="keywords" content="Itefs">

    <title>ITEFS</title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/moment/moment.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/jquery/jquery.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/jquery-date-range-picker-master/dist/jquery.daterangepicker.min.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/jquery.ganttView-master/lib/date.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/jquery.ganttView-master/lib/jquery-ui.min.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/jquery.ganttView-master/jquery.ganttView.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/jquery.ganttView-master/example/data.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/main.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/custom.js')); ?>" defer></script>
    <script src="https://use.fontawesome.com/1f3c336efc.js"></script>
    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <?php echo view('laravel-trix::trixassets')->render(); ?>
    <!-- Styles -->

    <link href="<?php echo e(asset('js/jquery-date-range-picker-master/dist/daterangepicker.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('js/jquery.ganttView-master/lib/jquery-ui.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('js/jquery.ganttView-master/example/reset.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('js/jquery.ganttView-master/jquery.ganttView.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/main.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/customs.css')); ?>" rel="stylesheet">
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                <img src="../images/bisonte.png" class="img-fluid" alt="Responsive image">
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                            </li>
                            <?php if(Route::has('Registarse')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Registrarse')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Cerrar Sesión')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <?php if(trim($__env->yieldContent('content'))): ?>
            <main class="py-4">
                <?php echo $__env->yieldContent('content'); ?>
            </main>
        <?php endif; ?>
        <?php if(trim($__env->yieldContent('chart-canvas'))): ?>
            <main class="p-0">
                <?php echo $__env->yieldContent('chart-canvas'); ?>
            </main>
        <?php endif; ?>
    </div>
    <?php echo $__env->yieldContent('script'); ?>
</body>
</html>
<?php /**PATH C:\Users\ITEFS-BACKEND\Documents\Desarrrollo Bisonte Pruebas\Report_Original\resources\views/layouts/app.blade.php ENDPATH**/ ?>