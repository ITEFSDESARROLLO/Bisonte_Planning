<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">Nuevo > Linea de Producción</div>
                    <div class="card-body">
                        <form class="" method="POST" action="<?php echo e(url('LineasProduccion')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <div class="position-relative form-group">
                                <label for="lineas" class="">Planta</label>
                                <input name="planta" id="nameFeatures"
                                       placeholder=""
                                       type="integer"
                                       class="form-control">
                            </div>

                            <div class="position-relative form-group">
                                <label for="titleProjects" class="">Nombre de Linea</label>
                                <input name="title" id="titleProjects"
                                       placeholder=""
                                       type="text"
                                       class="form-control">
                            </div>
                            <div class="position-relative form-group">
                                <label for="organizationsProjects" class="">Responsable</label>
                                <select name="organizations_id" id="organizationsProjects" class="form-control">
                                    <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $organization): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($organization->id); ?>"><?php echo e($organization->contact); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <button class="mt-1 btn btn-primary">Enviar</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ITEFS-BACKEND\Documents\Desarrrollo Bisonte Pruebas\Report_Original16\resources\views/LineasProduccion/create.blade.php ENDPATH**/ ?>