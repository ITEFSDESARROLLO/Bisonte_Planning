<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">Nuevo > ISSUE > <?php echo e($report->project->title); ?></div>

                    <div class="card-body">
                        <form class="" method="POST" action="<?php echo e(url('issues')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="projects_id" value="<?php echo e($report->project->id); ?>">
                            <input type="hidden" name="report_id" value="<?php echo e($report->id); ?>">
                            <div class="position-relative form-group">
                                <label for="titleProjects" class="">Titulo</label>
                                <input name="title" id="titleProjects"
                                       placeholder=""
                                       type="text"
                                       class="form-control">
                            </div>
                            <div class="position-relative form-group">
                                <label for="tagIssues" class="">Etiqueta</label>
                                <select name="tag_id" id="tagIssues" class="form-control">
                                    <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($tag->id); ?>"><?php echo e($tag->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="position-relative form-group">
                                <table class="mb-0 table">
                                    <thead>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td width="70%">
                                                <input type="checkbox" id="check_<?php echo e($feature->id); ?>" name="features[<?php echo e($feature->id); ?>]"
                                                       value="<?php echo e($feature->id); ?>" <?php echo e(($feature->default_value) ? 'checked':''); ?>>
                                                <label for="check_<?php echo e($feature->id); ?>"><?php echo e($feature->name); ?></label>
                                            </td>
                                            <td>
                                                <input name="hours_list[<?php echo e($feature->id); ?>]" id="nameFeatures"
                                                       placeholder=""
                                                       type="number"
                                                       class="form-control">
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="position-relative form-group">
                                <label for="developerIssues" class="">Developer</label>
                                <select name="users_id" id="developerIssues" class="form-control">
                                    <?php $__currentLoopData = $developers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $developer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($developer->id); ?>"><?php echo e($developer->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="position-relative form-group">
                                <label for="observationsIssues" class="">Descripcion</label>
                                <textarea name="observations" id="observationsIssues"
                                       placeholder=""
                                       class="form-control">
                                </textarea>
                            </div>
                            <button class="mt-1 btn btn-primary">Enviar</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\n.moreno.GLSLOG\Documents\APP\Report_Original\resources\views/issues/create.blade.php ENDPATH**/ ?>