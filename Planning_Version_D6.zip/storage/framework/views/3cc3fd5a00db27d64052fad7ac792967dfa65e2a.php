<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                <div class="card-header">Nuevo > Ordenes de Producción</div>
                    <div class="card-body">
                        <form class="" method="POST" action="<?php echo e(url('ProcesosProduccion')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <div class="position-relative form-group">
                                <label for="nameTags" class="">Numero</label>
                                <input name="name" id="nameTags"
                                       placeholder=""
                                       type="text"
                                       class="form-control">
                            </div>
                            <div class="position-relative form-group">
                                <label for="cantidadTags" class="">Cantidad</label>
                                <input name="cantidad" id="cantidadTags"
                                       placeholder=""
                                       type="integer"
                                       class="form-control">
                            </div>
                            <div class="position-relative form-group">
                                <label for="startAtTags" class="">Inicio</label>
                                <input name="start_at" id="startAtTags"
                                       placeholder=""
                                       type="date"
                                       class="form-control">
                            </div>
                            <div class="position-relative form-group">
                                <label for="deadLineAtTags" class="">Final</label>
                                <input name="deadline_at" id="deadLineAtTags"
                                       placeholder=""
                                       type="date"
                                       class="form-control">
                            </div>
                            <div class="position-relative form-group">
                                <label for="colorTags" class="">Color</label>
                                <input name="color" id="colorTags"
                                       placeholder=""
                                       type="color"
                                       class="form-control">
                            </div>
                            <div class="position-relative form-group">
                                <label for="projectTags" class="">Linea de Producción</label>
                                <select name="projects_id" id="projectTags" class="form-control">
                                    <?php $__currentLoopData = $LineasProduccion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($project->id); ?>"><?php echo e($project->title); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <!--<?php echo app('laravel-trix')->make(\App\Tags::class, 'content'); ?>-->
                            <button class="mt-1 btn btn-primary">Enviar</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ITEFS-BACKEND\Documents\Desarrrollo Bisonte Pruebas\Report_Original\resources\views/ProcesosProduccion/create.blade.php ENDPATH**/ ?>